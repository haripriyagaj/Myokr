import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import MyOKRs from './pages/MyOKRs';
import TeamOKRs from './pages/TeamOKRs';
import Organisation from './pages/Organisation';
import ProtectedRoute from './components/ProtectedRoute';
import Unauthorized from './pages/Unauthorized';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route
          path="/dashboard"
          element={<ProtectedRoute><Dashboard /></ProtectedRoute>}
        />
        <Route
          path="/my-okrs"
          element={<ProtectedRoute><MyOKRs /></ProtectedRoute>}
        />
        <Route
          path="/team-okrs"
          element={<ProtectedRoute><TeamOKRs /></ProtectedRoute>}
        />
        <Route
          path="/organisation"
          element={<ProtectedRoute adminOnly={true}><Organisation /></ProtectedRoute>}
        />
        <Route path="/unauthorized" element={<Unauthorized />} />
      </Routes>
    </Router>
  );
}

export default App;
