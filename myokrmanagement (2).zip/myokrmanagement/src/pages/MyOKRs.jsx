import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import {
  collection,
  addDoc,
  query,
  where,
  getDocs,
  doc,
  deleteDoc,
} from 'firebase/firestore';

function MyOKRs() {
  const [okrs, setOkrs] = useState([]);
  const [objective, setObjective] = useState('');
  const [loading, setLoading] = useState(false);

  // Fetch current user's OKRs
  const fetchOKRs = async () => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'okrs'),
      where('userId', '==', auth.currentUser.uid)
    );

    const snapshot = await getDocs(q);
    const userOKRs = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));

    setOkrs(userOKRs);
  };

  useEffect(() => {
    fetchOKRs();
  }, []);

  // Add new OKR
  const handleAddOKR = async () => {
    if (!objective.trim()) return;

    setLoading(true);
    try {
      await addDoc(collection(db, 'okrs'), {
        userId: auth.currentUser.uid,
        objective,
        keyResults: [],
        createdAt: new Date().toISOString(),
      });
      setObjective('');
      fetchOKRs();
    } catch (error) {
      console.error('Error adding OKR:', error);
    }
    setLoading(false);
  };

  // Delete OKR
  const handleDelete = async (id) => {
    try {
      await deleteDoc(doc(db, 'okrs', id));
      fetchOKRs();
    } catch (error) {
      console.error('Error deleting OKR:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 text-gray-800 p-6">
      <h1 className="text-2xl font-bold text-purple-600 mb-6">My OKRs</h1>

      {/* Form to add new OKR */}
      <div className="bg-white p-4 rounded shadow mb-6">
        <h2 className="text-lg font-semibold mb-2">Add New Objective</h2>
        <div className="flex gap-4">
          <input
            type="text"
            className="flex-1 px-4 py-2 border rounded"
            value={objective}
            onChange={(e) => setObjective(e.target.value)}
            placeholder="Enter your objective"
          />
          <button
            onClick={handleAddOKR}
            disabled={loading}
            className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700"
          >
            {loading ? 'Adding...' : 'Add'}
          </button>
        </div>
      </div>

      {/* OKR List */}
      <div className="grid gap-4">
        {okrs.map((okr) => (
          <div
            key={okr.id}
            className="bg-white p-4 rounded shadow flex justify-between items-center"
          >
            <div>
              <h3 className="font-semibold text-lg text-blue-800">
                {okr.objective}
              </h3>
              <p className="text-sm text-gray-500">
                Created: {new Date(okr.createdAt).toLocaleDateString()}
              </p>
            </div>
            <button
              onClick={() => handleDelete(okr.id)}
              className="text-red-600 text-sm hover:underline"
            >
              Delete
            </button>
          </div>
        ))}
        {okrs.length === 0 && (
          <p className="text-gray-500">No OKRs added yet.</p>
        )}
      </div>
    </div>
  );
}

export default MyOKRs;
