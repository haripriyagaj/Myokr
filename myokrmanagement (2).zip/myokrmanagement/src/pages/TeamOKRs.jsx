import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  getDoc
} from 'firebase/firestore';

function TeamOKRs() {
  const [teamMembers, setTeamMembers] = useState([]);
  const [okrs, setOkrs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTeamOKRs = async () => {
      try {
        // Step 1: Get current user's team info
        const userRef = doc(db, 'users', auth.currentUser.uid);
        const currentUserSnap = await getDoc(userRef);
        const { teamId, orgId } = currentUserSnap.data();

        if (!teamId || !orgId) {
          setLoading(false);
          return;
        }

        // Step 2: Get all users in the same team
        const userQuery = query(
          collection(db, 'users'),
          where('orgId', '==', orgId),
          where('teamId', '==', teamId)
        );

        const teamUserSnap = await getDocs(userQuery);
        const users = teamUserSnap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data()
        }));
        setTeamMembers(users);

        // Step 3: Fetch each member's OKRs
        const allOKRs = [];
        for (const user of users) {
          const okrQuery = query(
            collection(db, 'okrs'),
            where('userId', '==', user.id)
          );
          const okrSnap = await getDocs(okrQuery);
          okrSnap.forEach((doc) => {
            allOKRs.push({
              id: doc.id,
              ...doc.data(),
              owner: user.name || user.email
            });
          });
        }

        setOkrs(allOKRs);
      } catch (error) {
        console.error('Failed to fetch team OKRs:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTeamOKRs();
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-2xl font-bold text-purple-600 mb-4">Team OKRs</h1>
      {loading ? (
        <p>Loading team OKRs...</p>
      ) : okrs.length === 0 ? (
        <p className="text-gray-500">No OKRs found for your team.</p>
      ) : (
        <div className="grid gap-4">
          {okrs.map((okr) => (
            <div key={okr.id} className="bg-white p-4 rounded shadow">
              <h2 className="text-lg font-semibold text-blue-700">{okr.objective}</h2>
              <p className="text-sm text-gray-600">Owner: {okr.owner}</p>
              <p className="text-xs text-gray-400">
                Created: {new Date(okr.createdAt).toLocaleDateString()}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default TeamOKRs;
