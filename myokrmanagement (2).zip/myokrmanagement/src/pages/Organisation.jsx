import React, { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import {
  doc, getDoc, updateDoc,
  query, where, getDocs, collection
} from 'firebase/firestore';
import { v4 as uuidv4 } from 'uuid';

function Organisation() {
  const [orgId, setOrgId] = useState('');
  const [orgData, setOrgData] = useState(null);
  const [newDept, setNewDept] = useState('');
  const [newTeam, setNewTeam] = useState({});
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState('');

  // Fetch current user's org ID
  const fetchUserOrg = async () => {
    const uid = auth.currentUser?.uid;
    if (!uid) return;
    const userDoc = await getDoc(doc(db, 'users', uid));
    if (userDoc.exists()) {
      setOrgId(userDoc.data().orgId);
    }
  };

  // Fetch organisation and users
  useEffect(() => { fetchUserOrg(); }, []);
  useEffect(() => {
    if (!orgId) return;
    const fetchOrgData = async () => {
      const orgSnap = await getDoc(doc(db, 'organisations', orgId));
      if (orgSnap.exists()) setOrgData(orgSnap.data());
    };
    const fetchUsersInOrg = async () => {
      const q = query(collection(db, 'users'), where('orgId', '==', orgId));
      const querySnapshot = await getDocs(q);
      setUsers(querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    };
    fetchOrgData();
    fetchUsersInOrg();
  }, [orgId]);

  // Add new department
  const addDepartment = async () => {
    if (!newDept.trim()) return;
    const updated = [...(orgData?.departments || []), {
      id: uuidv4(), name: newDept, teams: []
    }];
    await updateDoc(doc(db, 'organisations', orgId), { departments: updated });
    setNewDept('');
    const orgSnap = await getDoc(doc(db, 'organisations', orgId));
    setOrgData(orgSnap.data());
  };

  // Add team under department
  const addTeam = async (deptId) => {
    const teamName = newTeam[deptId];
    if (!teamName?.trim()) return;

    const updatedDepartments = orgData.departments.map(dept => {
      if (dept.id === deptId) {
        return {
          ...dept,
          teams: [...(dept.teams || []), { id: uuidv4(), name: teamName, users: [] }]
        };
      }
      return dept;
    });

    await updateDoc(doc(db, 'organisations', orgId), { departments: updatedDepartments });
    setNewTeam(prev => ({ ...prev, [deptId]: '' }));
    const orgSnap = await getDoc(doc(db, 'organisations', orgId));
    setOrgData(orgSnap.data());
  };

  // Assign user to team
  const assignUserToTeam = async (deptId, teamId) => {
    if (!selectedUser) return;

    const updatedDepartments = orgData.departments.map(dept => {
      if (dept.id === deptId) {
        const updatedTeams = dept.teams.map(team => {
          if (team.id === teamId) {
            const users = new Set(team.users || []);
            users.add(selectedUser);
            return { ...team, users: [...users] };
          }
          return team;
        });
        return { ...dept, teams: updatedTeams };
      }
      return dept;
    });

    await updateDoc(doc(db, 'organisations', orgId), { departments: updatedDepartments });
    await updateDoc(doc(db, 'users', selectedUser), { teamId });
    const orgSnap = await getDoc(doc(db, 'organisations', orgId));
    setOrgData(orgSnap.data());
  };

  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <h1 className="text-2xl font-bold text-blue-600 mb-6">Organisation Structure</h1>

      {orgData ? (
        <div className="space-y-8">
          <div>
            <h2 className="text-xl font-semibold">Organisation: {orgData.name}</h2>
          </div>

          {/* Add Department */}
          <div className="bg-white p-4 rounded shadow max-w-md">
            <h3 className="font-semibold mb-2">Add Department</h3>
            <div className="flex gap-2">
              <input
                type="text"
                value={newDept}
                onChange={(e) => setNewDept(e.target.value)}
                placeholder="Department name"
                className="flex-1 px-3 py-2 border rounded"
              />
              <button
                onClick={addDepartment}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                Add
              </button>
            </div>
          </div>

          {/* Departments */}
          {orgData.departments?.map(dept => (
            <div key={dept.id} className="bg-white p-4 rounded shadow border border-blue-100">
              <h4 className="text-lg font-semibold mb-2">📂 {dept.name}</h4>

              {/* Teams */}
              <ul className="pl-4 space-y-1">
                {dept.teams?.map(team => (
                  <li key={team.id} className="mb-2">
                    <strong>Team:</strong> {team.name}
                    <div className="flex items-center gap-2 mt-1">
                      <select
                        value={selectedUser}
                        onChange={(e) => setSelectedUser(e.target.value)}
                        className="border px-2 py-1 rounded"
                      >
                        <option value="">Select user</option>
                        {users.map((u) => (
                          <option key={u.id} value={u.id}>
                            {u.name || u.email}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={() => assignUserToTeam(dept.id, team.id)}
                        className="bg-indigo-600 text-white px-3 py-1 rounded hover:bg-indigo-700"
                      >
                        Assign
                      </button>
                    </div>
                  </li>
                ))}
                {dept.teams?.length === 0 && (
                  <li className="text-gray-400 italic">No teams yet</li>
                )}
              </ul>

              {/* Add Team */}
              <div className="flex gap-2 mt-3">
                <input
                  type="text"
                  placeholder="Team name"
                  value={newTeam[dept.id] || ''}
                  onChange={(e) => setNewTeam((prev) => ({
                    ...prev, [dept.id]: e.target.value
                  }))}
                  className="flex-1 px-3 py-2 border rounded"
                />
                <button
                  onClick={() => addTeam(dept.id)}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                  Add Team
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p>Loading organisation details...</p>
      )}
    </div>
  );
}

export default Organisation;
