import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { auth } from '../firebase';

function Dashboard() {
  const user = auth.currentUser;
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await auth.signOut();
      navigate('/login');
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-tr from-white via-blue-50 to-blue-100 p-6">
      <div className="max-w-5xl mx-auto bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold text-blue-700 mb-2">
          Welcome, {user?.displayName || user?.email}!
        </h1>
        <p className="text-gray-600 mb-6">
          Your personalized dashboard for managing Objectives & Key Results.
        </p>

        <div className="grid gap-6 md:grid-cols-2">
          <DashboardCard
            title="🎯 My OKRs"
            description="View and manage your personal OKRs."
            to="/my-okrs"
          />
          <DashboardCard
            title="👥 Team OKRs"
            description="Track what your team is working on."
            to="/team-okrs"
          />
          <DashboardCard
            title="🏢 Organisation"
            description="Admins can manage org structure here."
            to="/organisation"
          />
          <DashboardCard
            title="🚪 Logout"
            description="Sign out of your account."
            onClick={handleLogout}
          />
        </div>
      </div>
    </div>
  );
}

function DashboardCard({ title, description, to, onClick }) {
  const Tag = to ? Link : 'button';

  return (
    <Tag
      to={to}
      onClick={onClick}
      className="block border rounded-lg p-5 shadow-sm hover:shadow-md transition bg-blue-50 hover:bg-blue-100 text-left"
    >
      <h2 className="font-semibold text-lg text-blue-800 mb-1">{title}</h2>
      <p className="text-sm text-gray-600">{description}</p>
    </Tag>
  );
}

export default Dashboard;
