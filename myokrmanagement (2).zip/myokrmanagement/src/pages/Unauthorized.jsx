// File: src/pages/Unauthorized.jsx
import React from 'react';

function Unauthorized() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 text-red-600 text-xl font-bold">
      🚫 Access Denied — You are not authorized to view this page.
    </div>
  );
}

export default Unauthorized;
